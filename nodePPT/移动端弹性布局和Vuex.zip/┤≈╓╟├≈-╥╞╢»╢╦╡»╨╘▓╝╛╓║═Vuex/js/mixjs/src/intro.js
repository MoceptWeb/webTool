(function(window, undefined) {
'use strict';
var document = window.document;
var setTimeout = window.setTimeout;